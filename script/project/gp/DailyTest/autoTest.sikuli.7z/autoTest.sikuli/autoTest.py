timer = 120;
Sta_ApIp='192.168.59.1'
Sta_PcIp='192.168.59.2'
Sta_DutIp='192.168.59.3'
Ap_PcIp='192.168.25.101'
Ap_DutIp='192.168.25.1'
loop = 3
isAllTest = 1
#+++++++++++++++++++show desktop++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++
def showDeskTop():
    #rightClick("1438602071175.png")
    #click("1438602146425.png")
    type("d",KEY_WIN) 
  
#++++++++++++++++++++saveAllLog++d++++++++++++++++++++
#copy screenss
#stop Tera term
#stop sniffer and save the sniffer log
#++++++++++++++++++++++++++++++++++++++++++++++++++++
def saveAllLog(SNIFFE_FILE,CHANNEL):
    #copy screen 
    #type(Key.PRINTSCREEN)
    showDeskTop()
    #stop the tera term log
    click("1438312446774.png")
    wait(2)
    if exists("1438312487976.png"):
        click("1438312487976.png")
    else:
        if exists("1438933719271.png"):
            click("1438933719271.png")
    wait(2) 
    click("1438312535102.png")
    click("1438312548505.png") 
    #stop sniffer
    showDeskTop()
    click("1438310824352.png")
    wait(1)
    click(Pattern("1438310838822.png").similar(0.49))
    
    #save sniffer file
    type("s",KEY_CTRL)
    wait(1)
    click("1438311118126.png")
    wait(1)
    doubleClick("1439176449832.png")
    wait(1)
    type("1438311254448.png", SNIFFE_FILE)
    type("-ch")  
    
    type(CHANNEL)        
    click("1438311310839.png")
    wait(10)
    showDeskTop()
    
 


#++++++++++++++++++++OpenTeraTermLog+++++++++++++++++
#open the Tera Term log to save log message
#++++++++++++++++++++++++++++++++++++++++++++++++++++
def OpenTeraTermLog(TERA_TERM_NAME,CHANNEL):
    click("1438329183328.png")
    wait(2)
    find("1438662243056.png")
    click("1438662790973.png")
       
    type(Key.DOWN)
    type(Key.DOWN)
    type(Key.DOWN)
    type(Key.DOWN)
    type(Key.ENTER)
    wait(2)

    
    if exists(Pattern("1438312624403.png").similar(0.90)):
        click("1438312672840.png")

    if(TERA_TERM_NAME == "sta-ping"):
        if(isAllTest == 1):
            if(CHANNEL == "01"):
                click("1439195483718.png")
        else:            
            if(CHANNEL == "06"):
                click("1439195483718.png")
    wait(1)
    click("1438328007903.png")
    wait(1)
    click("1438322839813.png")
    
    click("1438321259390.png")
    type("daily")
    doubleClick("1438321395270.png")
    type("1438325551056.png",Key.BACKSPACE)
    for i in range(11):
        type(Key.BACKSPACE)
    type(TERA_TERM_NAME)
    type("-log-ch")
    type(CHANNEL)
    
    click("1438312355760.png")   

    showDeskTop()


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def setAPChannel(CHANNEL):
    wait(10)
    click("1438247860403.png")    
    wait(20)
    click(Pattern("1438248123816.png").similar(0.66))
    type("192.168.59.1")
    type(Key.ENTER)
    wait(10)
    click("1438248226645.png")
    wait(12)
    click("1438305883655.png")
    wait(3)
    
    type(Key.TAB)
    type(Key.TAB)
    #type(Key.TAB)
    type(CHANNEL)
    click("1438248400362.png")
    wait(12)
    #click("1438660316863.png")
    type("w",Key.CTRL)
    showDeskTop()
    
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
def stopDosServer():
    click("1438686858265.png")
    
    #click(Pattern("1438686858265.png").targetOffset(150,-100))
    wait(1)
    type("c",Key.CTRL)   
    showDeskTop()
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
def startDosServer():
    click("1438686858265.png")
    #click(Pattern("1438686858265.png").targetOffset(150,-100))
    wait(1)
    type("iperf3.exe -s")
    type(Key.ENTER)
    showDeskTop()

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=
def startDutServer():
    click("1438329183328.png")
    type("iperf3 -s")
    type(Key.ENTER)
    showDeskTop()
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=
def stopDutServer():
    click("1438329183328.png")
    type("iperf3 stop")
    type(Key.ENTER)
    showDeskTop()

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  set SnifferChannel
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def setSnifferChannel(chNum):
    #change channel 06
    click("1438310824352.png")
    wait(2)
    rightClick("1438311361751.png")
    
    click("1438311431165.png")
    wait(1)
    if(chNum == "01"):
        #click(Pattern("1439097665738.png").targetOffset(0,-22))
        type(Key.DOWN);
        type(Key.ENTER);
    if(chNum == "06"):
        for k in range(13):
            type(Key.DOWN);
        type(Key.ENTER);
        
    if(chNum == "11"):
        #click("1439097730649.png")
        for k in range(13):
            type(Key.DOWN);
        type(Key.ENTER);
    wait(2)
    
    click("1439097440688.png")
    showDeskTop()


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#  setModuleChannel
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def startTestAp(chNum):
    click("1438329183328.png")
    click(Pattern("1438654933407.png").similar(0.52))
    wait(2)
    type("ctl ap on auto-test ")
    type(chNum)
    type(Key.ENTER) 
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def runIperf(cmd,isTcp,isTx):
       
    for i in range(loop):

        if(isTx == 1):
            click("1439085624812.png")
            wait(1)
            click(Pattern("1438654933407.png").similar(0.52))
        else:
            click("1438686858265.png")
            #click(Pattern("1438686858265.png").targetOffset(150,-100))
            if not exists("1439185167350.png"):
               type("c",Key.CTRL) 
        #type(Key.ENTER)
        wait(2)
        type(cmd)
        type(Key.ENTER)
        wait(timer+10)
        type(Key.ENTER)
        if(isTcp ==1):
            if(isTx==1):
                
                dragDrop(Pattern("1439084678452.png").targetOffset(-217,0), "1438657456415.png")
                click("1438657477945.png")
            else:
                
                rightClick(Pattern("1439086676517.png").similar(0.51))
                click(Pattern("1439086720002.png").targetOffset(0,-56))
                dragDrop(Pattern("1439086465175.png").targetOffset(-200,-4), Pattern("1439086558746.png").targetOffset(140,4))
                type(Key.ENTER) 
        else:
            if(isTx==1):
                 
                #dragDrop(Pattern("1439084678452.png").targetOffset(-217,0),Pattern("1439085015822.png").targetOffset(0,-12))
                dragDrop(Pattern("1439084678452.png").targetOffset(-217,0),"1439100803873.png")
                click("1438657962216.png") 
            else :
                
                rightClick(Pattern("1439086676517.png").similar(0.36))
                click(Pattern("1439086720002.png").targetOffset(0,-56))
                dragDrop(Pattern("1439086465175.png").targetOffset(-200,-4),Pattern("1439087047480.png").targetOffset(318,-5))
                type(Key.ENTER)
        
        click("1438318649993.png")
       
        type(Key.ENTER)
        
        type("============================")
        if(i==0):
            type(" first  loop")
        if(i==1):
            type(" second loop")
        if(i==2):
            type(" third  loop")
        type("===============================")
        type(Key.ENTER)
        type("v",Key.CTRL)
        type(Key.ENTER)
        wait(2)
        showDeskTop()

def insertPage():
    click("1439112820555.png")
    if exists("1439112967821.png"):
        click(Pattern("1439112967821.png").targetOffset(8,0))
        wait(2)
    if exists("1439113037165.png"):
        click(Pattern("1439113037165.png").targetOffset(-2,18))
    if exists("1440050250245.png"):
        click(Pattern("1440050250245.png").targetOffset(39,-2))
    showDeskTop()
    
    
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#SAT TEST CASE
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#save the log
def staTestCase(chNum):
     
    #++++++++++++++++++++++++++++++++++
    #iw scan and iw join
    #++++++++++++++++++++++++++++++++++ 
    OpenTeraTermLog("sta-ping",chNum)
    click("1438329183328.png")
    click("1438654933407.png") 
    wait(2)
    for k in range(10): 
      type("iw scan 0xffff")
      type(Key.ENTER)
      wait(10)
      type("iw join OOX")
      type(Key.ENTER)
      wait(3)
      if exists("1438672234271.png"):
          print "join-OOX ok"
          break
      else:
          print "join-OOX fail"
          
    #++++++++++++++++++++++++++++++++++
    #ping -c 20 192.168.59.1
    #++++++++++++++++++++++++++++++++++
    type("ping -c 20 "+Sta_ApIp)
    type(Key.ENTER)
    wait(30)
    
    dragDrop(Pattern("1438656988165.png").targetOffset(-19,0), Pattern("1440388726162.png").similar(0.52).targetOffset(159,18))
    click("1438657080662.png")
    
    
    #end :test scan and ping AP 
    #screen paste to word
    click("1438318649993.png")
    #input Station test
    type("########################################################################")
    type(Key.ENTER)
    type("STATION TEST:")
    type(Key.ENTER)    
    type("########################################################################")
    type(Key.ENTER)
    type("Channel ")
    type(chNum)
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: Ping AP")
    type(Key.ENTER)
    type("cmd: ping -c 20 "+Sta_ApIp)
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("v",Key.CTRL)
    type(Key.ENTER)
    saveAllLog("sta-ping",chNum);
    insertPage();
    #++++++++++++++++++++++++++++++++++
    #iperf3 -c 192.168.59.1 -t 120
    #++++++++++++++++++++++++++++++++++
    startDosServer()
    #sniffer start
    click("1438329105486.png")
    wait(1)
    click("1438329079608.png")
    showDeskTop()
    
    OpenTeraTermLog("sta-tx",chNum)
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: TCP TX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Sta_PcIp+" -t "+str(timer))
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    runIperf("iperf3 -c "+Sta_PcIp+" -t "+str(timer),1,1)
    
    wait(2)
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: UDP TX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Sta_PcIp+" -t "+str(timer)+"-u -b 14M")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    
    runIperf("iperf3 -c "+Sta_PcIp+" -t "+str(timer)+" -u -b 14M",0,1)
    saveAllLog("sta-tx",chNum)
    #++++++++++++
    # STA RX
    #++++++++++++
    stopDosServer()
    startDutServer()
    insertPage();
    #sniffer start
    click("1438329105486.png")
    wait(1)
    click("1438329079608.png")
    showDeskTop()
    
    OpenTeraTermLog("sta-rx",chNum)
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: TCP RX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Sta_DutIp+" -t "+str(timer))
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    runIperf("iperf3 -c "+Sta_DutIp+" -t "+str(timer),1,0)
    
    wait(2)
    
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: UDP RX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Sta_DutIp+"-t "+str(timer)+" -u -b 14M")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    runIperf("iperf3 -c "+Sta_DutIp+" -t "+str(timer)+" -u -b 14M",0,0)
    saveAllLog("sta-rx",chNum)
    stopDutServer()
    click("1438329183328.png") 
    type("iw leave")
    type(Key.ENTER)
    showDeskTop()

def pcDisconnectAp():
      #pc try to connect the test ap
    
    click("1438686858265.png")
    #click(Pattern("1438686858265.png").targetOffset(150,-100))
    wait(1)
    type(Key.ENTER)
    type("c:\\tools\\disconnectAP.bat")
    type(Key.ENTER)
    wait(10)
   
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def apTestCase(chNum):
    #setSnifferChannel(chNum)
    OpenTeraTermLog("ap-ping",chNum)
    if(chNum == "01"):
        startTestAp("1")
    if(chNum == "06"):
        startTestAp("6")
    if(chNum == "11"):
        startTestAp("11")
    wait(5)
    #pc try to connect the test ap
    
    click("1438686858265.png")
    #click(Pattern("1438686858265.png").targetOffset(150,-100))
    wait(1)
    type(Key.ENTER)
    type("c:\\tools\\connectAP.bat")
    type(Key.ENTER)
    wait(15)
    showDeskTop()
    wait(1)
    click("1438329183328.png")
    wait(2)
    click("1438654933407.png")
   
    wait(2)
    type(Key.ENTER)
    wait(2)
    type("ping -c 20 ")
    type(Ap_PcIp)
    type(Key.ENTER)
    
    wait(30)
    
    dragDrop(Pattern("1438656988165.png").targetOffset(-19,0), Pattern("1440060305034.png").targetOffset(161,8))
    click("1438657080662.png")
    
    
    #end :test scan and ping AP 
    insertPage();
    #record to word
    click("1438318649993.png")
    #input Station test
    type("########################################################################")
    type(Key.ENTER)
    type("AP TEST:")
    type(Key.ENTER)    
    type("########################################################################")
    type(Key.ENTER)
    type("Channel ")
    type(chNum)
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: Ping STA")
    type(Key.ENTER)
    type("cmd: ping -c 20 "+Ap_PcIp)
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("v",Key.CTRL)
    type(Key.ENTER)
    saveAllLog("ap-ping",chNum);
    startDosServer()
    insertPage();
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: TCP TX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Ap_PcIp+" -t "+str(timer))
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    OpenTeraTermLog("ap-tx",chNum)
    runIperf("iperf3 -c "+Ap_PcIp+" -t "+str(timer),1,1)
    wait(2)
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: UDP TX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Ap_PcIp+" -t "+str(timer)+" -u -b 14M")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    runIperf("iperf3 -c "+Ap_PcIp+" -t "+str(timer)+" -u -b 14M",0,1)
    saveAllLog("ap-tx",chNum) 
    #+++++++++++++++++++++
    # AP RX
    #+++++++++++++++++++++
    stopDosServer()
    startDutServer()
    insertPage();
     #sniffer start
    click("1438329105486.png")
    wait(1)
    click("1438329079608.png")
    showDeskTop()
    
    OpenTeraTermLog("ap-rx",chNum)
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: TCP RX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Ap_DutIp+" -t "+str(timer))
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    runIperf("iperf3 -c "+Ap_DutIp+" -t "+str(timer),1,0)
    
    wait(2)
 
    click("1438318649993.png")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    type("case: UDP RX throughput")
    type(Key.ENTER)
    type("cmd: iperf3 -c "+Ap_DutIp+" -t "+str(timer)+" -u -b 14M")
    type(Key.ENTER)
    type("==========================================================================")
    type(Key.ENTER)
    showDeskTop()
    runIperf("iperf3 -c "+Ap_DutIp+" -t "+str(timer)+" -u -b 14M",0,0)
    saveAllLog("ap-rx",chNum)
    stopDutServer()
    #click("1438329183328.png") 
    #type("ctl ap off")
    #type(Key.ENTER)
    showDeskTop()
    
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# main funciton
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#open word

click("1438153403048.png")
doubleClick("1438318016739.png")
wait(1)
#if exists("1440120610345.png"):
#    click("1440120610345.png")
wait(7)

#if exists(Pattern("1438318117939.png").similar(0.49)):

click("1438318128394.png")


showDeskTop()
#for team viever
if exists("1438953675843.png"):

    click("1438953714244.png")


#open the Tera Term

click("1438153403048.png")
wait(1)
click("1438153470869.png")

wait(2)
if exists(Pattern("1438153669362.png").exact()):
    print "error"
    click("1438153703643.png")
    wait(1)
    click("1438157691319.png")
    type(Key.DOWN)
    type(Key.ENTER)
    wait(1)
    if exists("1438153977412.png"):
        click("1438153994841.png")
else:
    wait(1)
    if exists("1438914413381.png"):        
        click("1438914413381.png")
 
type(Key.ENTER)
wait(1)
#start :test scan and ping AP 
#if not exists("1438154102755.png"):
#    print "system fail"
#else:
#    print "system ok"
showDeskTop()
OpenTeraTermLog("sw-version","all")

#open expoler
click("1438150135397.png")
wait(2)
click(Pattern("1439118300720.png").targetOffset(0,-10))
wait(2)
doubleClick("1438150454018.png")
wait(1)
doubleClick("1438148354734.png")
wait(1)
##doubleClick("1438915651814.png")

##doubleClick("1438915631875.png")
doubleClick("1438915613784.png")
wait(1)
doubleClick("1438148505229.png")
wait(1)
doubleClick("1438148534232.png")
wait(1)
doubleClick("1438148594051.png")
wait(1)
doubleClick("1438148653306.png")
wait(1)
doubleClick("1438148813024.png")
wait(1)
doubleClick("1438148841142.png")
wait(1)
doubleClick("1438149038071.png")

#type("1439171018451.png","C:\daily-build-gp\iot-host-8546-20150824\iot-host-8546-20150824-6060P\os\MicroC\gp3260xxa_15B_release_v0.0.2\project\GP3260xxa\gp3260xxa_platform_demo_release_captureRaw_lincorr_Data\Release")
#type(Key.ENTER)
wait(1)
doubleClick("1438149103143.png")
wait(30)
wait("1438149236114.png")
click("1438149251394.png")
wait(2)
for i in range(3): 
    wait(4)
    if exists("1438149251394.png"):
         click("1438149251394.png")
    else:
         break
        
wait(5)
click("1440554873928.png")
wait(2)
type("f",Key.ALT)
type(Key.UP)
type(Key.ENTER)
wait(2)
showDeskTop()


#open the sniffer

click("1438246489484.png")
wait(10)
if exists("1439181750125.png"):
    click(Pattern("1439181750125.png").targetOffset(5,-10))
#wait("1438911739934.png",10)

#click("1438246522853.png")

type("n",KEY_CTRL)
wait(5)
click(Pattern("1439085313511.png").targetOffset(-170,-1))
find(Pattern("1438247212621.png").similar(0.52))
click("1438247232686.png")
find("1438247340295.png")

dragDrop("1438246756064.png", "1438247462303.png")

click("1438247597268.png")
#find("1438247654104.png")
click("1438247671251.png")
wait(1)
click("1438247715718.png")

showDeskTop()
#open dos iperf3 -s

click("1438153403048.png")
type("1440382902292.png","cmd"+Key.ENTER)

wait(2)
type("cd C:\\tools\iperf3\Win\iperf3.0.11")
type(Key.ENTER)
showDeskTop()
#stop the tera term log
click("1438312446774.png")
wait(2)
if exists("1438312487976.png"):
    click("1438312487976.png")
else:
    if exists("1438933719271.png"):
        click("1438933719271.png")
wait(2) 
click("1438312535102.png")
click("1438312548505.png") 

#STA TEST
if(isAllTest == 1):
    setAPChannel("01")
    staTestCase("01")    
setAPChannel("06")
setSnifferChannel("06")
staTestCase("06")
if(isAllTest == 1):
    setAPChannel("11")
    setSnifferChannel("11")
    staTestCase("11")

    
######++++++++++++++++++++++++++++++++++++
######AP TEST
######++++++++++++++++++++++++++++++++++++
if(isAllTest == 1):
    setSnifferChannel("01")
    apTestCase("01")
    pcDisconnectAp()
setSnifferChannel("06")
apTestCase("06")
pcDisconnectAp()
if(isAllTest == 1):
    setSnifferChannel("11")
    apTestCase("11")
    pcDisconnectAp()
#close all windows

click("1438318649993.png")
#click("1438843790332.png")
type("s",Key.CTRL)
wait(1)
type(Key.DELETE)
type("d:\\dailyreport\\dailyTestReport")
click("1438843950965.png")
wait(2)
type("f",Key.ALT)
type("x",Key.ALT)
wait(2)
showDeskTop()
#close tera term
click("1438329183328.png") 
wait(1)
type("q",Key.ALT)
wait(2)
#close dos command line
click("1438686858265.png")
#click(Pattern("1438686858265.png").targetOffset(150,-100))
type("exit")
type(Key.ENTER)
wait(2)

click("1438246489484.png")
wait(2)
type("f",Key.ALT)
type(Key.UP)
type(Key.ENTER)
wait(2)

click("1439107401810.png")
wait(2)
click(Pattern("1439107433903.png").targetOffset(-200,0))

wait(2)
type("f",Key.ALT)
type(Key.UP)
type(Key.ENTER)
wait(1)
type(Key.ENTER)
wait(1)
type(Key.LEFT)
type(Key.ENTER)








